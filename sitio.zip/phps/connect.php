<?php
    //$connect = mysql_connect('localhost','dancor36_1','Vaneamor') or die('Imposible conectarse');
    
    $connect = mysqli_connect('localhost','u244902295_odst','Vaneamor','u244902295_odst');
    //mysql_select_db('u244902295_odst',$connect);
    if($connect){
        echo '<script>alert("Estamos conectados");</script>';
    } else {
        echo '<script>alert("Valio queso men");</script>';
    }

?>
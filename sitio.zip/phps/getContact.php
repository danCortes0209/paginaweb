<?php 
	$db_host = "localhost";
	$db_name = "u244902295_odst";
	$db_user = "u244902295_odst";
	$db_password = "Vaneamor";
	$id_contacto = "";
	
	$connection = mysqli_connect($db_host, $db_user, $db_password, $db_name) or die("Connection Error: ");
	
	//mysql_select_db($db_name) or die("Error al seleccionar la base de datos:".mysqli_error());
	//@mysql_query("SET NAMES'utf8'");

	$id_contacto = $_POST['id'];

	if(isset($id_contacto)){
	
		$sql_query = "SELECT * FROM productos WHERE id=".$id_contacto.";";
		$result = mysqli_query($connection,$sql_query);
		$rows = array();
	
	while($r = mysqli_fetch_assoc($result)) {
		$rows[] = $r;
	}
	
	print json_encode($rows);
	
	}else
		echo "No existe el producto";
		mysqli_close($connection);
?>
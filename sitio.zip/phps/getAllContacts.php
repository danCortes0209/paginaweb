<?php 
	$db_host = "localhost";
	$db_name = "u244902295_odst";
	$db_user = "u244902295_odst";
	$db_pass = "Vaneamor";

	$connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name) or die ("Connection Error: ");

	//mysql_select_db($db_name) or die("Error al seleccionar la base de datos:".mysqli_error());
		//@mysql_query("SET NAMES'utf8'");

	$sql_query = "SELECT * FROM productos;";
	$result = mysqli_query($connection,$sql_query);
	$rows = array();
	
	while($r = mysqli_fetch_assoc($result)) {
  		$rows[] = $r;
	}

	print json_encode($rows);

?>